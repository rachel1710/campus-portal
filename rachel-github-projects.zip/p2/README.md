# Personal Portfolio & Landing Page Website
HTML5, CSS3, JavaScript. Tanpa build tool.

## Menjalankan
Buka `index.html` di peramban.

## Publikasi (GitHub Pages)
Settings > Pages > Branch `main` / root. Situs tayang di `https://rachel1710.github.io/portfolio/`.
