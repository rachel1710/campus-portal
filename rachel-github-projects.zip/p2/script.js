const root = document.documentElement;
const themeBtn = document.getElementById('theme');
const menuBtn = document.querySelector('.menu-btn');
const nav = document.getElementById('nav');

try {
  const saved = localStorage.getItem('theme');
  if (saved) root.dataset.theme = saved;
} catch (e) {}

themeBtn.addEventListener('click', () => {
  const dark = getComputedStyle(root).colorScheme === 'dark';
  const next = dark ? 'light' : 'dark';
  root.dataset.theme = next;
  try { localStorage.setItem('theme', next); } catch (e) {}
});

menuBtn.addEventListener('click', () => {
  const open = nav.classList.toggle('open');
  menuBtn.setAttribute('aria-expanded', open);
});
nav.addEventListener('click', e => {
  if (e.target.tagName === 'A') { nav.classList.remove('open'); menuBtn.setAttribute('aria-expanded', false); }
});
